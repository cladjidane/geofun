# Running the example

This example is intended to show users how to consume the polymer-simple-slider element.

In order to test it, please run `bower install` command so that the element will be installed in the `examples` folder.

Now just open the `examples/index.html` file.

